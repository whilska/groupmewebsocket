
from distutils.core import setup

setup(
        name="groupmewebsocket",
        author="William Hilska",
        author_email="whilska@gmail.com",
        version="1.0.2",
        py_modules=["groupmewebsocket"]
)